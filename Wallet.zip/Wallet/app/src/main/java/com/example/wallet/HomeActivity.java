package com.example.wallet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null){
           String NumeroTarjeta = bundle.getString("NumeroTarjerta","");
            String FechaExpiacion = bundle.getString("FechaExpiacion","");
            String CodigoSeguridad = bundle.getString("CodigoSeguridad","");
            String NombreTrajeta = bundle.getString("NombreTarjeta","");
        }

    }
}